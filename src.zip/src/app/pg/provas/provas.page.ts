import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provas',
  templateUrl: './provas.page.html',
  styleUrls: ['./provas.page.scss'],
})
export class ProvasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
